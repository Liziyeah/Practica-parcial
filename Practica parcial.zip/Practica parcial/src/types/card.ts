export interface CardInfo {
	id: string;
	name: string;
	color: string;
	letra: string;
}
